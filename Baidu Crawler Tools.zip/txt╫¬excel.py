import re
import pandas as pd

# 读取文本文件
with open('D:\\桌面\\[OCR]_河北_20250318_1910.txt', 'r', encoding='utf-8') as file:
    text = file.read()

# 提取每个警情通报的正则表达式
report_pattern = re.compile(r'≦ (.*?) ≧\n(.*?)\n((?:.*?\n)*?)(?=\n≦|\Z)', re.DOTALL)

# 提取信息的正则表达式
area_pattern = re.compile(r'(\w+市|\w+区|\w+县|\w+镇)')
date_pattern = re.compile(r'(\d{4}年\d{1,2}月\d{1,2}日)')

# 存储提取的信息
data = {
    "地区": [],
    "日期": [],
    "事件内容": []
}

# 遍历每个警情通报并提取信息
for match in report_pattern.finditer(text):
    title = match.group(1)
    content = match.group(3)

    # 提取最后一个地区
    areas = area_pattern.findall(content)
    last_area = areas[-1] if areas else ""

    # 提取最后一个日期
    dates = date_pattern.findall(content)
    last_date = dates[-1] if dates else ""

    # 事件内容为标题之后的所有内容，不包括标题
    event_content = content.strip()

    # 添加到数据字典
    data["地区"].append(last_area)
    data["日期"].append(last_date)
    data["事件内容"].append(event_content)

# 创建DataFrame
df = pd.DataFrame(data)

# 保存为Excel文件
df.to_excel("警情通报汇总5.xlsx", index=False)