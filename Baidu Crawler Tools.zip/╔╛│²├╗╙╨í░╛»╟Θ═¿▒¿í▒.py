import pandas as pd

# 读取 Excel 文件
file_path = 'D:\\桌面\\50%重复.xlsx'  # 替换为你的 Excel 文件路径
df = pd.read_excel(file_path)

# 筛选出第三列（索引为 2）中包含“警情通报”的行
original_count = len(df)
df = df[df.iloc[:, 2].str.contains('警情通报', na=False)]

# 计算删除的行数
deleted_count = original_count - len(df)

# 保存处理后的 DataFrame 到新的 Excel 文件
output_file_path = 'D:\\桌面\\processed_excel_file.xlsx'  # 替换为你想要保存的文件路径
df.to_excel(output_file_path, index=False)

# 汇报删除的行数
print(f"一共删除了 {deleted_count} 条记录。")