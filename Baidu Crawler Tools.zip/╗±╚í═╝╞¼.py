import os
from paddleocr import PaddleOCR
import time
from datetime import datetime


class OCRSystem:
    def __init__(self,
                 use_gpu=False,
                 lang='ch',
                 det=True,
                 rec=True,
                 use_angle_cls=True,
                 show_log=False):
        """
        初始化OCR系统
        Parameters:
            use_gpu: 是否使用GPU，默认False
            lang: 识别语言，默认中文
            det: 是否进行文本检测，默认True
            rec: 是否进行文本识别，默认True
            use_angle_cls: 是否使用方向分类器，默认True
            show_log: 是否显示日志，默认False
        """
        # 设置环境变量（可选）
        os.environ['PADDLEOCR_HOME'] = os.path.expanduser('~/.paddleocr/')

        # 初始化PaddleOCR
        self.ocr = PaddleOCR(
            use_gpu=use_gpu,  # 是否使用GPU
            lang=lang,  # 识别语言
            det=det,  # 是否检测
            rec=rec,  # 是否识别
            use_angle_cls=use_angle_cls,  # 是否使用方向分类器
            show_log=show_log,  # 是否显示日志
            # 可选：指定模型路径
            # det_model_dir='path/to/det_model',
            # rec_model_dir='path/to/rec_model',
            # cls_model_dir='path/to/cls_model'
        )

        self.supported_formats = ['.jpg', '.jpeg', '.png', '.bmp']

    def process_image(self, image_path):
        """
        处理单个图片
        Parameters:
            image_path: 图片路径
        Returns:
            处理结果列表
        """
        try:
            # 检查文件是否存在
            if not os.path.exists(image_path):
                raise FileNotFoundError(f"图片不存在: {image_path}")

            # 检查文件格式
            file_ext = os.path.splitext(image_path)[1].lower()
            if file_ext not in self.supported_formats:
                raise ValueError(f"不支持的文件格式: {file_ext}")

            # 执行OCR
            result = self.ocr.ocr(image_path, cls=True)

            # 处理结果
            processed_results = []
            if result:
                for idx, line in enumerate(result):
                    for item in line:
                        text = item[1][0]  # 识别的文字
                        confidence = item[1][1]  # 置信度
                        processed_results.append({
                            'text': text,
                            'confidence': confidence,
                            'position': item[0]  # 文字位置
                        })

            return processed_results

        except Exception as e:
            print(f"处理图片时出错: {str(e)}")
            return None

    def save_results(self, results, output_path):
        """
        保存识别结果到文件
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                for result in results:
                    f.write(f"文字: {result['text']}\n")
                    f.write(f"置信度: {result['confidence']:.4f}\n")
                    f.write(f"位置: {result['position']}\n")
                    f.write("-" * 50 + "\n")
        except Exception as e:
            print(f"保存结果时出错: {str(e)}")


def main():
    # 使用示例

    # 1. 创建OCR系统实例（这里可以设置各种初始化参数）
    ocr_system = OCRSystem(
        use_gpu=False,  # 如果有GPU可以设置为True
        lang='ch',  # 中文识别
        det=True,  # 进行文本检测
        rec=True,  # 进行文本识别
        use_angle_cls=True,  # 使用方向分类器
        show_log=True  # 显示日志
    )

    # 2. 设置输入输出路径
    image_path = "D:\\桌面\\新建文件夹\\警情通报"  # 替换为您的图片路径
    output_path = "result.txt"  # 结果保存路径

    # 3. 处理图片
    print(f"开始处理图片: {image_path}")
    start_time = time.time()

    results = ocr_system.process_image(image_path)

    # 4. 输出结果
    if results:
        print("\n识别结果:")
        for result in results:
            print(f"文字: {result['text']}")
            print(f"置信度: {result['confidence']:.4f}")
            print(f"位置: {result['position']}")
            print("-" * 50)

        # 保存结果到文件
        ocr_system.save_results(results, output_path)
        print(f"\n结果已保存到: {output_path}")
    else:
        print("未能识别出文字或处理过程出错")

    # 5. 输出处理时间
    end_time = time.time()
    print(f"\n处理用时: {end_time - start_time:.2f} 秒")


if __name__ == "__main__":
    main()