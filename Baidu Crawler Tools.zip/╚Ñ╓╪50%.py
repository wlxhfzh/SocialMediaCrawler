import pandas as pd
from difflib import SequenceMatcher

# 读取Excel文件
df = pd.read_excel("警情通报汇总5.xlsx")

#删除第一列或第二列为空的行
df = df.dropna(subset=[df.columns[0], df.columns[1]])

# 去除事件内容列重复度达到50%以上的行，只保留第一个
def is_similar(a, b, threshold=0.5):
    return SequenceMatcher(None, a, b).ratio() > threshold

def remove_similar_rows(df, col_name):
    unique_rows = []
    total_rows = len(df)
    for index, row in df.iterrows():
        if not any(is_similar(row[col_name], unique_row[col_name]) for unique_row in unique_rows):
            unique_rows.append(row)
        # 显示处理进度
        print(f"处理进度: {index + 1}/{total_rows} 行")
        if index + 1 >= total_rows:
            break

    return pd.DataFrame(unique_rows)

# 处理重复的事件内容
df = remove_similar_rows(df, df.columns[2])

# 保存处理后的Excel文件
df.to_excel("去除重复的警情通报汇总5.xlsx", index=False)