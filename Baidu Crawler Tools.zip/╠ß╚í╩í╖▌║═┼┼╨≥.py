import pandas as pd
import re
import cpca

# 正则匹配发布主体所在地区
def extract_region(text):
    if not isinstance(text, str):
        return None
    pattern = r'([\u4e00-\u9fa5]{2,})'
    matches = re.findall(pattern, text)
    if matches:
        df = cpca.transform(matches, pos_sensitive=True)
        valid_regions = []
        for _, row in df.iterrows():
            if row['省'] or row['市'] or row['区']:
                if row['省']:
                    valid_regions.append(row['省'])
                if row['市']:
                    valid_regions.append(row['市'])
                if row['区']:
                    valid_regions.append(row['区'])
        if valid_regions:
            return valid_regions[0]
    return None

# 使用 cpca 解析省份
def parse_province(region):
    if not region:
        return None

    try:
        df = cpca.transform([region], pos_sensitive=True)
        province = df.iat[0, 0]  # 省
        city = df.iat[0, 1]  # 市

        # 直辖市特殊处理（如"北京市公安局" → 北京）
        if pd.isna(province) and city in ['北京', '上海', '天津', '重庆']:
            return city
        return province
    except Exception as e:
        print(f"解析地址时出现错误：{e}，地区：{region}")
        return None

# 提取事件内容中的最后一个日期
def extract_last_date(event_content):
    if not isinstance(event_content, str):
        return None
    date_pattern = r'\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?'
    matches = re.findall(date_pattern, event_content)
    if matches:
        return matches[-1]
    return None

# 主处理流程
def main():
    try:
        # 读取 Excel 文件（修改为实际路径）
        input_path = "D:\\桌面\\去重结果.xlsx"
        output_path = "校正结果.xlsx"

        # 读取数据
        df = pd.read_excel(input_path)
        print(df.head())

        # 提取发布主体地区
        df['发布地区'] = df['事件内容'].apply(extract_region)

        # 解析省份
        df['校正省份'] = df['发布地区'].apply(parse_province)

        # 优先使用校正后的省份，缺失时保留原省份
        df['最终省份'] = df['校正省份'].combine_first(df['省份'])

        # 提取事件内容中的最后一个日期
        df['最后一个日期'] = df['事件内容'].apply(extract_last_date)

        # 将日期转换为 datetime 类型，方便排序
        df['最后一个日期'] = pd.to_datetime(df['最后一个日期'], errors='coerce')

        # 按照最终省份和最后一个日期列进行排序
        df = df.sort_values(by=['最终省份', '最后一个日期'])

        # 去除不需要的列
        df = df.drop(['发布地区', '校正省份', '省份'], axis=1)

        # 保存结果
        df.to_excel(output_path, index=False)
        print(f"处理完成，已保存至：{output_path}")
    except Exception as e:
        print(f"处理过程中出现错误：{e}")

if __name__ == "__main__":
    main()