import os
from paddleocr import PaddleOCR
import time
from datetime import datetime
import pandas as pd
import re
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from difflib import SequenceMatcher
import numpy as np
import shutil


class MultiFolderOCR:
    def __init__(self,
                 use_gpu=False,
                 lang='ch',
                 similarity_threshold=0.5,
                 current_user='我是懒羊羊'):
        """
        初始化OCR系统
        """
        self.ocr = PaddleOCR(
            use_gpu=use_gpu,
            lang=lang,
            use_angle_cls=True,
            show_log=False
        )

        self.similarity_threshold = similarity_threshold
        self.supported_formats = ['.jpg', '.jpeg', '.png', '.bmp']
        self.current_user = current_user

    def calculate_similarity(self, text1, text2):
        """计算两个文本之间的相似度"""
        return SequenceMatcher(None, text1, text2).ratio()

    def format_time(self, seconds):
        """格式化时间显示"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds = int(seconds % 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def get_progress_bar(self, progress, width=50):
        """生成进度条"""
        filled_length = int(width * progress)
        bar = '█' * filled_length + '-' * (width - filled_length)
        return f"[{bar}] {progress * 100:.1f}%"

    def extract_address(self, text):
        """提取文本中的地址"""
        address_patterns = [
            r'地址[：:]\s*(.+?)(?=\d|$|。|，|,|\s)',
            r'(?:省|市|区|县|镇|街道|路|号)(?:[^\d]{0,50}?(?:省|市|区|县|镇|街道|路|号)){2,}',
            r'(?:[\u4e00-\u9fa5]{2,}(?:省|市|区|县|镇|街道|路|号))+'
        ]

        for pattern in address_patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                address = match.group().strip()
                if len(address) > 5:
                    return address
        return ""

    def extract_date(self, text):
        """提取文本中的日期"""
        date_patterns = [
            r'\d{4}[-年/]\d{1,2}[-月/]\d{1,2}[日号]?',
            r'\d{4}\.\d{1,2}\.\d{1,2}',
            r'\d{4}[-/]\d{1,2}[-/]\d{1,2}'
        ]

        for pattern in date_patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                date = match.group()
                date = date.replace('年', '-').replace('月', '-').replace('日', '')
                date = date.replace('/', '-').replace('.', '-')
                try:
                    datetime.strptime(date, '%Y-%m-%d')
                    return date
                except ValueError:
                    continue
        return ""

    def process_image(self, image_path):
        """处理单个图片"""
        try:
            if not os.path.exists(image_path):
                raise FileNotFoundError(f"图片不存在: {image_path}")

            file_ext = os.path.splitext(image_path)[1].lower()
            if file_ext not in self.supported_formats:
                return None

            result = self.ocr.ocr(image_path, cls=True)

            full_text = ""
            if result:
                for line in result:
                    for item in line:
                        full_text += item[1][0] + "\n"

            return {
                'address': self.extract_address(full_text),
                'date': self.extract_date(full_text),
                'full_text': full_text.strip(),
                'image_path': image_path
            }

        except Exception as e:
            print(f"\n处理图片时出错 {image_path}: {str(e)}")
            return None

    def process_folders(self, root_folder, output_excel):
        """处理多个文件夹中的图片"""
        print("\n=== OCR 处理任务开始 ===")
        print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"处理用户: {self.current_user}")
        print(f"根目录: {root_folder}")

        # 读取现有Excel文件
        existing_texts = []
        if os.path.exists(output_excel):
            try:
                df = pd.read_excel(output_excel)
                existing_texts = df['识别结果'].tolist()
                print(f"已加载现有记录: {len(existing_texts)} 条")
            except Exception as e:
                print(f"读取Excel文件时出错: {str(e)}")
                existing_texts = []

        # 获取所有子文件夹和图片
        subfolders = [f.path for f in os.scandir(root_folder) if f.is_dir()]
        all_images = []

        print("\n=== 扫描文件夹 ===")
        for folder in subfolders:
            folder_name = os.path.basename(folder)
            images_in_folder = 0
            for root, _, files in os.walk(folder):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in self.supported_formats):
                        all_images.append({
                            'path': os.path.join(root, file),
                            'folder': folder_name,
                            'filename': file
                        })
                        images_in_folder += 1
            print(f"文件夹 {folder_name}: {images_in_folder} 张图片")

        total_images = len(all_images)
        print(f"\n总计待处理图片: {total_images} 张")

        if total_images == 0:
            print("未找到需要处理的图片，程序退出")
            return

        # 处理图片
        all_results = []
        processed_images = 0
        skipped_images = 0
        start_time = time.time()

        print("\n=== 开始处理 ===")
        for img in all_images:
            # 清除当前行并显示进度
            print('\r' + ' ' * shutil.get_terminal_size().columns, end='')
            print('\r', end='')

            # 计算进度和预计剩余时间
            processed_images += 1
            progress = processed_images / total_images
            elapsed_time = time.time() - start_time
            estimated_total_time = elapsed_time / progress if progress > 0 else 0
            remaining_time = estimated_total_time - elapsed_time

            # 显示当前处理信息
            print(f"正在处理: {img['folder']}/{img['filename']}")
            print(f"进度: {self.get_progress_bar(progress)}")
            print(f"已处理: {processed_images}/{total_images} | 已跳过: {skipped_images}")
            print(f"用时: {self.format_time(elapsed_time)} | 预计还需: {self.format_time(remaining_time)}")

            # 处理图片
            result = self.process_image(img['path'])
            if result:
                # 检查相似度
                if not any(self.calculate_similarity(result['full_text'], text) > self.similarity_threshold
                           for text in existing_texts if pd.notna(text)):
                    all_results.append(result)
                    existing_texts.append(result['full_text'])
                else:
                    skipped_images += 1

            # 每处理10张图片保存一次结果
            if len(all_results) > 0 and len(all_results) % 10 == 0:
                self.save_to_excel(all_results, output_excel)
                all_results = []

        # 保存剩余结果
        if all_results:
            self.save_to_excel(all_results, output_excel)

        # 显示最终统计
        total_time = time.time() - start_time
        print("\n=== 处理完成 ===")
        print(f"总计图片: {total_images}")
        print(f"成功处理: {processed_images}")
        print(f"因相似跳过: {skipped_images}")
        print(f"总用时: {self.format_time(total_time)}")
        print(f"结果已保存到: {output_excel}")

    def save_to_excel(self, results, output_path):
        """保存结果到Excel"""
        try:
            # 准备数据
            data = {
                '地址': [r['address'] for r in results],
                '日期': [r['date'] for r in results],
                '识别结果': [r['full_text'] for r in results],
                '图片路径': [r['image_path'] for r in results]
            }

            # 处理Excel文件
            if os.path.exists(output_path):
                existing_df = pd.read_excel(output_path)
                new_df = pd.DataFrame(data)
                df = pd.concat([existing_df, new_df], ignore_index=True)
            else:
                df = pd.DataFrame(data)

            # 保存到Excel
            df.to_excel(output_path, index=False)

            # 设置Excel样式
            wb = load_workbook(output_path)
            ws = wb.active

            # 设置表头样式
            header_fill = PatternFill(start_color='CCCCCC', end_color='CCCCCC', fill_type='solid')
            header_font = Font(bold=True)

            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font

            # 自动调整列宽
            for column in ws.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)  # 限制最大宽度
                ws.column_dimensions[column_letter].width = adjusted_width

            wb.save(output_path)

        except Exception as e:
            print(f"\n保存Excel时出错: {str(e)}")


def main():
    # 设置参数
    root_folder = "D:\\imgs\\直辖市"  # 替换为您的根文件夹路径
    output_excel = "ocr_results.xlsx"

    # 创建OCR实例
    ocr_system = MultiFolderOCR(
        use_gpu=False,
        lang='ch',
        similarity_threshold=0.5,
        current_user='我是懒羊羊'
    )

    # 处理文件夹
    ocr_system.process_folders(root_folder, output_excel)


if __name__ == "__main__":
    main()