import numpy as np
from scipy.optimize import minimize
from scipy.linalg import inv
import matplotlib.pyplot as plt


class IntegratedDNSModel:
    def __init__(self, maturities, lambda_=0.0609):
        """
        初始化扩展DNS模型

        参数:
        maturities: 期限结构
        lambda_: DNS模型形状参数
        """
        self.maturities = np.array(maturities)
        self.lambda_ = lambda_
        self.n_maturities = len(maturities)
        self.n_factors = 3

    def compute_loadings(self):
        """
        计算DNS模型的因子载荷

        返回:
        Z: 因子载荷矩阵 (n_maturities x 3)
        """
        tau = self.maturities
        lambda_ = self.lambda_

        # 水平因子载荷
        level = np.ones_like(tau)

        # 斜率因子载荷
        slope = (1 - np.exp(-lambda_ * tau)) / (lambda_ * tau)

        # 曲率因子载荷
        curvature = slope - np.exp(-lambda_ * tau)

        return np.column_stack((level, slope, curvature))

    def kalman_filter(self, y, params):
        """
        执行卡尔曼滤波并计算似然值

        参数:
        y: 观测数据 (T x n_maturities)
        params: 模型参数 [phi11, phi22, phi33, sigma_eta1, sigma_eta2, sigma_eta3, sigma_eps]

        返回:
        filtered_states: 滤波后的状态估计
        loglike: 对数似然值
        """
        T = len(y)

        # 解包参数
        phi11, phi22, phi33 = params[:3]
        sigma_eta1, sigma_eta2, sigma_eta3 = params[3:6]
        sigma_eps = params[6]

        # 构建系统矩阵
        Phi = np.diag([phi11, phi22, phi33])
        Q = np.diag([sigma_eta1 ** 2, sigma_eta2 ** 2, sigma_eta3 ** 2])
        H = sigma_eps ** 2 * np.eye(self.n_maturities)
        Z = self.compute_loadings()

        # 初始化
        beta = np.zeros((self.n_factors, 1))
        P = np.eye(self.n_factors) * 100

        # 存储结果
        filtered_states = np.zeros((T, self.n_factors))
        loglike = 0

        for t in range(T):
            # 预测步骤
            beta_pred = Phi @ beta
            P_pred = Phi @ P @ Phi.T + Q

            # 更新步骤
            y_pred = Z @ beta_pred
            y_obs = y[t].reshape(-1, 1)
            v = y_obs - y_pred  # 创新

            F = Z @ P_pred @ Z.T + H
            K = P_pred @ Z.T @ inv(F)

            beta = beta_pred + K @ v
            P = P_pred - K @ Z @ P_pred

            # 存储状态估计
            filtered_states[t] = beta.flatten()

            # 更新对数似然
            loglike += -0.5 * (np.log(2 * np.pi) * self.n_maturities +
                               np.log(np.linalg.det(F)) +
                               v.T @ inv(F) @ v)

        return filtered_states, float(loglike)

    def estimate(self, y, initial_params=None):
        """
        使用最大似然法估计模型参数

        参数:
        y: 观测数据
        initial_params: 初始参数猜测值

        返回:
        estimated_params: 估计的参数
        filtered_states: 滤波后的状态
        """
        if initial_params is None:
            initial_params = np.array([0.97, 0.97, 0.97, 0.1, 0.1, 0.1, 0.1])

        # 定义负对数似然函数
        def objective(params):
            _, loglike = self.kalman_filter(y, params)
            return -loglike

        # 参数约束
        bounds = [(0, 0.9999)] * 3 + [(1e-6, None)] * 4

        # 优化
        result = minimize(objective, initial_params,
                          bounds=bounds,
                          method='L-BFGS-B')

        # 使用最优参数进行最后一次滤波
        filtered_states, _ = self.kalman_filter(y, result.x)

        return result.x, filtered_states

    def plot_results(self, y, estimated_states, true_states=None):
        """
        绘制估计结果

        参数:
        y: 观测数据
        estimated_states: 估计的状态
        true_states: 真实状态（如果有）
        """
        plt.figure(figsize=(15, 10))

        # 绘制三个状态变量
        titles = ['Level Factor', 'Slope Factor', 'Curvature Factor']
        for i in range(3):
            plt.subplot(2, 2, i + 1)
            plt.plot(estimated_states[:, i], 'r-', label='Estimated')
            if true_states is not None:
                plt.plot(true_states[:, i], 'b--', label='True')
            plt.title(titles[i])
            plt.legend()
            plt.grid(True)

        # 绘制收益率拟合
        plt.subplot(2, 2, 4)
        plt.boxplot(y)
        plt.title('Yield Curve Distribution')
        plt.xlabel('Maturity')
        plt.ylabel('Yield (%)')

        plt.tight_layout()
        plt.show()


def generate_synthetic_data(T=500, maturities=[0.25, 0.5, 1, 2, 3, 5, 7, 10]):
    """
    生成模拟数据

    参数:
    T: 时间长度
    maturities: 期限结构

    返回:
    y: 模拟的收益率数据
    true_params: 真实参数
    true_states: 真实状态
    """
    np.random.seed(42)

    # 真实参数
    true_params = np.array([0.97, 0.94, 0.91, 0.1, 0.1, 0.1, 0.1])
    phi = np.diag(true_params[:3])

    # 生成状态
    beta = np.zeros((T, 3))
    beta[0] = [5, -2, 1]

    for t in range(1, T):
        beta[t] = phi @ beta[t - 1] + np.random.normal(0, true_params[3:6])

    # 创建模型实例计算因子载荷
    model = IntegratedDNSModel(maturities)
    Z = model.compute_loadings()

    # 生成观测数据
    y = np.zeros((T, len(maturities)))
    for t in range(T):
        y[t] = Z @ beta[t] + np.random.normal(0, true_params[6], len(maturities))

    return y, true_params, beta


def main():
    # 生成模拟数据
    maturities = [0.25, 0.5, 1, 2, 3, 5, 7, 10]
    y, true_params, true_states = generate_synthetic_data(T=500,
                                                          maturities=maturities)

    # 创建模型实例
    model = IntegratedDNSModel(maturities)

    # 估计参数
    estimated_params, estimated_states = model.estimate(y)

    # 打印结果
    print("\n参数估计结果:")
    print("-" * 50)
    param_names = ['phi11', 'phi22', 'phi33',
                   'sigma_eta1', 'sigma_eta2', 'sigma_eta3',
                   'sigma_eps']

    print(f"{'参数名':>10} {'真实值':>10} {'估计值':>10} {'相对误差%':>10}")
    print("-" * 50)
    for i, (name, true, est) in enumerate(zip(param_names, true_params, estimated_params)):
        rel_error = abs(true - est) / true * 100
        print(f"{name:>10} {true:>10.4f} {est:>10.4f} {rel_error:>10.2f}")

    # 计算RMSE
    rmse = np.sqrt(np.mean((estimated_states - true_states) ** 2, axis=0))
    print("\n状态估计的RMSE:")
    print("-" * 50)
    state_names = ['水平因子', '斜率因子', '曲率因子']
    for name, err in zip(state_names, rmse):
        print(f"{name}: {err:.4f}")

    # 绘制结果
    model.plot_results(y, estimated_states, true_states)


if __name__ == "__main__":
    main()